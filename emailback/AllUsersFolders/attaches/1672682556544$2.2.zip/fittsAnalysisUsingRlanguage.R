dis <- c(300,200,100,50,300,200,100,50,300,100,50)
width <- c(20,20 ,20 ,20,50 ,50 ,50 ,50,80 ,80,80)
t0 <- readLines("../m.txt")
t1 <- readLines("../m1.txt")
t2 <- readLines("../m2.txt")
t3 <- readLines("../m3.txt")
t <- (as.numeric(t0)+as.numeric(t1)+as.numeric(t2)+as.numeric(t3))/4
r <- log(dis/width)
plot(r,t,xlab = "ID=log2(l/w)",ylab = "Average time")