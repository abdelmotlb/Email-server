import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import static java.lang.System.currentTimeMillis;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class gui  extends JFrame implements ActionListener {
    //declareations
    JButton bleft, bright, bcenter;
    long mytime, mytime2= 0;
    int count = 0;
    int state = 0;
    int w, sp;
    int[] arrdis = {200,100,50,300,200,100,50,300,100,50};
    int[] arrw =   {20 ,20 ,20,50 ,50 ,50 ,50,80 ,80,80};

    //constractor
    public gui(int width, int dis)throws IOException{
        //variables
        w = width;
        int space1 = 50 + width + dis;
        int space2 = 50 + width*2 + dis*2;
        sp = dis;
        //display the window
        setTitle("Fitts");
        setSize(1000,800);
        setResizable(false);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocation(350,0);
        //set buttons
        bleft = new JButton();
        bright = new JButton();
        bcenter = new JButton();
        //set buttons on window
        setLayout(null);
        this.add(bleft);
        bleft.setBounds(50, 325, width, 50);
        this.add(bright);
        bright.setBounds(space2, 325, width, 50);
        this.add(bcenter);
        bcenter.setBounds(space1, 325, width, 50);
        //actions assign
        bcenter.addActionListener(this);
        bright.addActionListener(this);
        bleft.addActionListener(this);
    }
    
    //events control
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == bcenter && count == 0)
        {
            mytime =  currentTimeMillis();
            count++;
        }
        else if(e.getSource() == bcenter || e.getSource() == bright || e.getSource() == bleft)
        {
            mytime2 += (currentTimeMillis() - mytime)/1000;
            
            mytime =  currentTimeMillis();
            count++;
        }
        if(count == 4)
        {
            
            double l = mytime2/3.0;
            try {
                write(l,"m2.txt");
            } catch (IOException ex) {
                Logger.getLogger(gui.class.getName()).log(Level.SEVERE, null, ex);
            }
            count = 0;
            mytime2 = 0;
              if(state <10)
              {
                  change(arrw[state],arrdis[state]) ;
                  state++;
              }
        }
    }
    
    //change width and distance of buttons
    public void change(int width, int dis)
    {
        int space1 = 50 + width + dis;
        int space2 = 50 + width*2 + dis*2;
        w = width;
        sp = dis;
        bleft.setBounds(50, 325, width, 50);
        bright.setBounds(space2, 325, width, 50);
        bcenter.setBounds(space1, 325, width, 50);
    }
//  write the time to external file
    public void write(double n, String f)throws IOException
    {
        BufferedWriter w = new BufferedWriter(new FileWriter(f,true));
        String s = n + "\n";
        w.append(s);
        w.close();
    }
}

