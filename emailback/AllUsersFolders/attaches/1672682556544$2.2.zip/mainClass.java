import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class mainClass {
    public static void main(String[] args){
        try {
            gui n = new gui(20,300);   
        } catch (IOException ex) {
            Logger.getLogger(mainClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
